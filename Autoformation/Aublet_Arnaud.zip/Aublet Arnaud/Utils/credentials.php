<?php

$dsn = 'pgsql:host=aquabdd;dbname=etudiants';
$login = "12203694";
$mdp = "081804053CE";

?>